/* File generated from [../compute/sample-programs/non-thread/sample.c] by PICCO Wed Aug  1 11:28:50 2018
 */

#include <limits.h>

#include <float.h>

//extern void *memcpy(void*,const void*,unsigned int);

//# 1 "ort.onoff.defs"

extern  "C" int   ort_initialize(int*, char***);
 extern "C" void  ort_finalize(int);


/* File generated from [../compute/sample-programs/non-thread/sample.c] by PICCO Wed Aug  1 11:28:50 2018
 */

#include "smc-compute/SMC_Utils.h"

#include <gmp.h>

#include <omp.h>


SMC_Utils *__s;


int N = 1024;

int logN = 10;


mpz_t  __original_main(int _argc_ignored, char **_argv_ignored)
{
  
  mpz_t _picco_tmp1;
  mpz_init(_picco_tmp1);

  mpz_t* _picco_ftmp1 = (mpz_t*)malloc(sizeof(mpz_t) * 4);
  for(int _picco_j = 0; _picco_j < 4; _picco_j++)
    mpz_init(_picco_ftmp1[_picco_j]);
  void* _picco_temp_;
   mpz_t _picco_priv_ind1, _picco_priv_ind2, _picco_priv_ind3;
  mpz_init(_picco_priv_ind1);
  mpz_init(_picco_priv_ind2);
  mpz_init(_picco_priv_ind3);
  mpz_t _picco_priv_tmp1, _picco_priv_tmp2;
  mpz_init(_picco_priv_tmp1);
  mpz_init(_picco_priv_tmp2);
mpz_t b;
  mpz_init(b);
  __s->smc_set(5, b, -1, 10, "int", -1);

  mpz_t* a; 
  a = (mpz_t*)malloc(sizeof(mpz_t) * (N));
  for (int _picco_i = 0; _picco_i < N; _picco_i++)
        mpz_init(a[_picco_i]);

  mpz_t c;
  mpz_init(c);

  int i;

  i = 0;
  for ( ;i < N; )
  {
    __s->smc_set(1, a[i], -1, 32, "int", -1);
    i++;
  }

      __s->smc_set(b, _picco_priv_ind1, 10, -1, "int", -1);
  __s->smc_privindex_read(_picco_priv_ind1, a, _picco_priv_tmp1, N, "int", -1);
  __s->smc_set(_picco_priv_tmp1, c, 32, 32, "int", -1);
}


/* smc-compiler generated main() */
int main(int argc, char **argv)
{

 if(argc < 8){
fprintf(stderr,"Incorrect input parameters\n");
fprintf(stderr,"Usage: <id> <runtime-config> <privatekey-filename> <number-of-input-parties> <number-of-output-parties> <input-share> <output>\n");
exit(1);
}

 std::string IO_files[atoi(argv[4]) + atoi(argv[5])];
for(int i = 0; i < argc-6; i++)
   IO_files[i] = argv[6+i];

__s = new SMC_Utils(atoi(argv[1]), argv[2], argv[3], atoi(argv[4]), atoi(argv[5]), IO_files, 3, 1, 59, "288230376151711919", 1);

struct timeval tv1;
struct timeval tv2;  int _xval = 0;

  gettimeofday(&tv1,NULL);
  _xval = (int) __original_main(argc, argv);
  gettimeofday(&tv2, NULL);
  std::cout << "Time: " << __s->time_diff(&tv1,&tv2) << std::endl;
  return (_xval);
}

