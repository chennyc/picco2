echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10_4_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10_4_utility"
file="./flag/10-4"
while [ ! -f "$file" ]
do
	eval "cd ."
done


echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10_7_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10_7_utility"
file="./flag/10-7"
while [ ! -f "$file" ]
do
	eval "cd ."
done

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10_10_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10_10_utility"
file="./flag/10-10"
while [ ! -f "$file" ]
do
	eval "cd ."
done


echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10_13_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10_13_utility"
file="./flag/10-13"
while [ ! -f "$file" ]
do
	eval "cd ."
done

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10_16_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10_16_utility"
file="./flag/10-16"
while [ ! -f "$file" ]
do
	eval "cd ."
done


#100
echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl100_4_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl100_4_utility"
file="./flag/100-4"
while [ ! -f "$file" ]
do
	eval "cd ."
done


echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl100_7_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl100_7_utility"
file="./flag/100-7"
while [ ! -f "$file" ]
do
	eval "cd ."
done

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl100_10_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl100_10_utility"
file="./flag/100-10"
while [ ! -f "$file" ]
do
	eval "cd ."
done


echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl100_13_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl100_13_utility"
file="./flag/100-13"
while [ ! -f "$file" ]
do
	eval "cd ."
done

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl100_16_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl100_16_utility"
file="./flag/100-16"
while [ ! -f "$file" ]
do
	eval "cd ."
done


##1000
echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1000_4_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1000_4_utility"
file="./flag/1000-4"
while [ ! -f "$file" ]
do
	eval "cd ."
done


echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1000_7_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1000_7_utility"
file="./flag/1000-7"
while [ ! -f "$file" ]
do
	eval "cd ."
done

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1000_10_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1000_10_utility"
file="./flag/1000-10"
while [ ! -f "$file" ]
do
	eval "cd ."
done


echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1000_13_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1000_13_utility"
file="./flag/1000-13"
while [ ! -f "$file" ]
do
	eval "cd ."
done

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1000_16_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl1000_16_utility"
file="./flag/1000-16"
while [ ! -f "$file" ]
do
	eval "cd ."
done

#10000
echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10000_4_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10000_4_utility"
file="./flag/10000-4"
while [ ! -f "$file" ]
do
	eval "cd ."
done


echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10000_7_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10000_7_utility"
file="./flag/10000-7"
while [ ! -f "$file" ]
do
	eval "cd ."
done

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10000_10_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10000_10_utility"
file="./flag/10000-10"
while [ ! -f "$file" ]
do
	eval "cd ."
done


echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10000_13_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10000_13_utility"
file="./flag/10000-13"
while [ ! -f "$file" ]
do
	eval "cd ."
done

echo "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10000_16_utility"
eval "./../compiler/bin/picco-seed runtime-config ./tl_file/tl10000_16_utility"
file="./flag/10000-16"
while [ ! -f "$file" ]
do
	eval "cd ."
done

