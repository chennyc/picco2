#10
echo "./tl10_4 1 runtime-config private-1.pem 1 1 ./tl_file/tl4_share1 tl4_out"
eval "./tl10_4 1 runtime-config private-1.pem 1 1 ./tl_file/tl4_share1 tl4_out"
sleep 5



echo "./tl10_7 1 runtime-config private-1.pem 1 1 ./tl_file/tl7_share1 tl7_out"
touch ./flag/10-4
eval "./tl10_7 1 runtime-config private-1.pem 1 1 ./tl_file/tl7_share1 tl7_out"
sleep 5



echo "./tl10_10 1 runtime-config private-1.pem 1 1 ./tl_file/tl10_share1 tl10_out"
touch ./flag/10-7
eval "./tl10_10 1 runtime-config private-1.pem 1 1 ./tl_file/tl10_share1 tl10_out"
sleep 5



echo "./tl10_13 1 runtime-config private-1.pem 1 1 ./tl_file/tl13_share1 tl13_out"
touch ./flag/10-10
eval "./tl10_13 1 runtime-config private-1.pem 1 1 ./tl_file/tl13_share1 tl13_out"
sleep 5




echo "./tl10_16 1 runtime-config private-1.pem 1 1 ./tl_file/tl16_share1 tl16_out"
touch ./flag/10-13
eval "./tl10_16 1 runtime-config private-1.pem 1 1 ./tl_file/tl16_share1 tl16_out"
sleep 5


#100
echo "./tl100_4 1 runtime-config private-1.pem 1 1 ./tl_file/tl4_share1 tl4_out"
touch ./flag/10-16
eval "./tl100_4 1 runtime-config private-1.pem 1 1 ./tl_file/tl4_share1 tl4_out"
sleep 5




echo "./tl100_7 1 runtime-config private-1.pem 1 1 ./tl_file/tl7_share1 tl7_out"
touch ./flag/100-4
eval "./tl100_7 1 runtime-config private-1.pem 1 1 ./tl_file/tl7_share1 tl7_out"
sleep 5



echo "./tl100_10 1 runtime-config private-1.pem 1 1 ./tl_file/tl10_share1 tl10_out"
touch ./flag/100-7
eval "./tl100_10 1 runtime-config private-1.pem 1 1 ./tl_file/tl10_share1 tl10_out"
sleep 5



echo "./tl100_13 1 runtime-config private-1.pem 1 1 ./tl_file/tl13_share1 tl13_out"
touch ./flag/100-10
eval "./tl100_13 1 runtime-config private-1.pem 1 1 ./tl_file/tl13_share1 tl13_out"
sleep 5




echo "./tl100_16 1 runtime-config private-1.pem 1 1 ./tl_file/tl16_share1 tl16_out"
touch ./flag/100-13
eval "./tl100_16 1 runtime-config private-1.pem 1 1 ./tl_file/tl16_share1 tl16_out"
sleep 5



#1000
echo "./tl1000_4 1 runtime-config private-1.pem 1 1 ./tl_file/tl4_share1 tl4_out"
touch ./flag/100-16
eval "./tl1000_4 1 runtime-config private-1.pem 1 1 ./tl_file/tl4_share1 tl4_out"
sleep 5




echo "./tl1000_7 1 runtime-config private-1.pem 1 1 ./tl_file/tl7_share1 tl7_out"
touch ./flag/1000-4
eval "./tl1000_7 1 runtime-config private-1.pem 1 1 ./tl_file/tl7_share1 tl7_out"
sleep 5



echo "./tl1000_10 1 runtime-config private-1.pem 1 1 ./tl_file/tl10_share1 tl10_out"
touch ./flag/1000-7
eval "./tl1000_10 1 runtime-config private-1.pem 1 1 ./tl_file/tl10_share1 tl10_out"
sleep 5



echo "./tl1000_13 1 runtime-config private-1.pem 1 1 ./tl_file/tl13_share1 tl13_out"
touch ./flag/1000-10
eval "./tl1000_13 1 runtime-config private-1.pem 1 1 ./tl_file/tl13_share1 tl13_out"
sleep 5




echo "./tl1000_16 1 runtime-config private-1.pem 1 1 ./tl_file/tl16_share1 tl16_out"
touch ./flag/1000-13
eval "./tl1000_16 1 runtime-config private-1.pem 1 1 ./tl_file/tl16_share1 tl16_out"
sleep 5



#10000
echo "./tl10000_4 1 runtime-config private-1.pem 1 1 ./tl_file/tl4_share1 tl4_out"
touch ./flag/1000-16
eval "./tl10000_4 1 runtime-config private-1.pem 1 1 ./tl_file/tl4_share1 tl4_out"
sleep 5




echo "./tl10000_7 1 runtime-config private-1.pem 1 1 ./tl_file/tl7_share1 tl7_out"
touch ./flag/10000-4
eval "./tl10000_7 1 runtime-config private-1.pem 1 1 ./tl_file/tl7_share1 tl7_out"
sleep 5



echo "./tl10000_10 1 runtime-config private-1.pem 1 1 ./tl_file/tl10_share1 tl10_out"
touch ./flag/10000-7
eval "./tl10000_10 1 runtime-config private-1.pem 1 1 ./tl_file/tl10_share1 tl10_out"
sleep 5



echo "./tl10000_13 1 runtime-config private-1.pem 1 1 ./tl_file/tl13_share1 tl13_out"
touch ./flag/10000-10
eval "./tl10000_13 1 runtime-config private-1.pem 1 1 ./tl_file/tl13_share1 tl13_out"
sleep 5




echo "./tl10000_16 1 runtime-config private-1.pem 1 1 ./tl_file/tl16_share1 tl16_out"
touch ./flag/10000-13
eval "./tl10000_16 1 runtime-config private-1.pem 1 1 ./tl_file/tl16_share1 tl16_out"
sleep 5

touch ./flag/10000-16
