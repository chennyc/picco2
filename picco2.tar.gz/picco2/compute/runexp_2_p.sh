#10
echo "./tl10_4 2 runtime-config private-2.pem 1 1 ./tl_file/tl4_share2 tl4_out"
eval "./tl10_4 2 runtime-config private-2.pem 1 1 ./tl_file/tl4_share2 tl4_out"
sleep 3

echo "./tl10_7 2 runtime-config private-2.pem 1 1 ./tl_file/tl7_share2 tl7_out"
eval "./tl10_7 2 runtime-config private-2.pem 1 1 ./tl_file/tl7_share2 tl7_out"
sleep 3

echo "./tl10_10 2 runtime-config private-2.pem 1 1 ./tl_file/tl10_share2 tl10_out"
eval "./tl10_10 2 runtime-config private-2.pem 1 1 ./tl_file/tl10_share2 tl10_out"
sleep 3

echo "./tl10_13 2 runtime-config private-2.pem 1 1 ./tl_file/tl13_share2 tl13_out"
eval "./tl10_13 2 runtime-config private-2.pem 1 1 ./tl_file/tl13_share2 tl13_out"
sleep 3


echo "./tl10_16 2 runtime-config private-2.pem 1 1 ./tl_file/tl16_share2 tl16_out"
eval "./tl10_16 2 runtime-config private-2.pem 1 1 ./tl_file/tl16_share2 tl16_out"
sleep 3
#100
echo "./tl100_4 2 runtime-config private-2.pem 1 1 ./tl_file/tl4_share2 tl4_out"
eval "./tl100_4 2 runtime-config private-2.pem 1 1 ./tl_file/tl4_share2 tl4_out"
sleep 3


echo "./tl100_7 2 runtime-config private-2.pem 1 1 ./tl_file/tl7_share2 tl7_out"
eval "./tl100_7 2 runtime-config private-2.pem 1 1 ./tl_file/tl7_share2 tl7_out"
sleep 3

echo "./tl100_10 2 runtime-config private-2.pem 1 1 ./tl_file/tl10_share2 tl10_out"
eval "./tl100_10 2 runtime-config private-2.pem 1 1 ./tl_file/tl10_share2 tl10_out"
sleep 3

echo "./tl100_13 2 runtime-config private-2.pem 1 1 ./tl_file/tl13_share2 tl13_out"
eval "./tl100_13 2 runtime-config private-2.pem 1 1 ./tl_file/tl13_share2 tl13_out"
sleep 3


echo "./tl100_16 2 runtime-config private-2.pem 1 1 ./tl_file/tl16_share2 tl16_out"
eval "./tl100_16 2 runtime-config private-2.pem 1 1 ./tl_file/tl16_share2 tl16_out"
sleep 3

#1000
echo "./tl1000_4 2 runtime-config private-2.pem 1 1 ./tl_file/tl4_share2 tl4_out"
eval "./tl1000_4 2 runtime-config private-2.pem 1 1 ./tl_file/tl4_share2 tl4_out"
sleep 3


echo "./tl1000_7 2 runtime-config private-2.pem 1 1 ./tl_file/tl7_share2 tl7_out"
eval "./tl1000_7 2 runtime-config private-2.pem 1 1 ./tl_file/tl7_share2 tl7_out"
sleep 3

echo "./tl1000_10 2 runtime-config private-2.pem 1 1 ./tl_file/tl10_share2 tl10_out"
eval "./tl1000_10 2 runtime-config private-2.pem 1 1 ./tl_file/tl10_share2 tl10_out"
sleep 3

echo "./tl1000_13 2 runtime-config private-2.pem 1 1 ./tl_file/tl13_share2 tl13_out"
eval "./tl1000_13 2 runtime-config private-2.pem 1 1 ./tl_file/tl13_share2 tl13_out"
sleep 3


echo "./tl1000_16 2 runtime-config private-2.pem 1 1 ./tl_file/tl16_share2 tl16_out"
eval "./tl1000_16 2 runtime-config private-2.pem 1 1 ./tl_file/tl16_share2 tl16_out"
sleep 3

#10000
echo "./tl10000_4 2 runtime-config private-2.pem 1 1 ./tl_file/tl4_share2 tl4_out"
eval "./tl10000_4 2 runtime-config private-2.pem 1 1 ./tl_file/tl4_share2 tl4_out"
sleep 3


echo "./tl10000_7 2 runtime-config private-2.pem 1 1 ./tl_file/tl7_share2 tl7_out"
eval "./tl10000_7 2 runtime-config private-2.pem 1 1 ./tl_file/tl7_share2 tl7_out"
sleep 3

echo "./tl10000_10 2 runtime-config private-2.pem 1 1 ./tl_file/tl10_share2 tl10_out"
eval "./tl10000_10 2 runtime-config private-2.pem 1 1 ./tl_file/tl10_share2 tl10_out"
sleep 3

echo "./tl10000_13 2 runtime-config private-2.pem 1 1 ./tl_file/tl13_share2 tl13_out"
eval "./tl10000_13 2 runtime-config private-2.pem 1 1 ./tl_file/tl13_share2 tl13_out"
sleep 3


echo "./tl10000_16 2 runtime-config private-2.pem 1 1 ./tl_file/tl16_share2 tl16_out"
eval "./tl10000_16 2 runtime-config private-2.pem 1 1 ./tl_file/tl16_share2 tl16_out"
sleep 3
