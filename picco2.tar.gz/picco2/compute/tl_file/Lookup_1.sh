picco="./../../compiler/bin/picco-utility"

${picco} -I 1 tl_4.txt tl1_4_utility tl4_share

${picco} -I 1 tl_5.txt tl1_5_utility tl5_share

${picco} -I 1 tl_6.txt tl1_6_utility tl6_share

${picco} -I 1 tl_7.txt tl1_7_utility tl7_share

${picco} -I 1 tl_8.txt tl1_8_utility tl8_share

${picco} -I 1 tl_9.txt tl1_9_utility tl9_share

${picco} -I 1 tl_10.txt tl1_10_utility tl10_share

${picco} -I 1 tl_11.txt tl1_11_utility tl11_share

${picco} -I 1 tl_12.txt tl1_12_utility tl12_share

${picco} -I 1 tl_13.txt tl1_13_utility tl13_share

${picco} -I 1 tl_14.txt tl1_14_utility tl14_share

${picco} -I 1 tl_15.txt tl1_15_utility tl15_share

${picco} -I 1 tl_16.txt tl1_16_utility tl16_share

${picco} -I 1 tl_17.txt tl1_17_utility tl17_share
