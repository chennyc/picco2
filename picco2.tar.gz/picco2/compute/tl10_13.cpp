/* File generated from [table_lookup_10_4.c] by PICCO Fri Dec  8 14:38:44 2017
 */

#include <limits.h>

#include <float.h>

//extern void *memcpy(void*,const void*,unsigned int);

//# 1 "ort.onoff.defs"

extern  "C" int   ort_initialize(int*, char***);
 extern "C" void  ort_finalize(int);


/* File generated from [table_lookup_10_4.c] by PICCO Fri Dec  8 14:38:44 2017
 */

#include "smc-compute/SMC_Utils.h"

#include <gmp.h>

#include <omp.h>


SMC_Utils *__s;


int M = 8192;

int N = 10;


int  __original_main(int _argc_ignored, char **_argv_ignored)
{
  
  mpz_t _picco_tmp1;
  mpz_init(_picco_tmp1);

  mpz_t* _picco_ftmp1 = (mpz_t*)malloc(sizeof(mpz_t) * 4);
  for(int _picco_j = 0; _picco_j < 4; _picco_j++)
    mpz_init(_picco_ftmp1[_picco_j]);
  void* _picco_temp_;
   mpz_t _picco_priv_ind1, _picco_priv_ind2, _picco_priv_ind3;
  mpz_init(_picco_priv_ind1);
  mpz_init(_picco_priv_ind2);
  mpz_init(_picco_priv_ind3);
  mpz_t _picco_priv_tmp1, _picco_priv_tmp2;
  mpz_init(_picco_priv_tmp1);
  mpz_init(_picco_priv_tmp2);
mpz_t* result; 
  result = (mpz_t*)malloc(sizeof(mpz_t) * (N));
  for (int _picco_i = 0; _picco_i < N; _picco_i++)
        mpz_init(result[_picco_i]);

  mpz_t* array; 
  array = (mpz_t*)malloc(sizeof(mpz_t) * (M));
  for (int _picco_i = 0; _picco_i < M; _picco_i++)
        mpz_init(array[_picco_i]);

  mpz_t A;
  mpz_init(A);

  int i;

  __s->smc_input(1, array, M, "int", -1);

  __s->smc_input(1, &A, "int", -1);
  int j = 0;
  for ( ;j < 100; )
  {
  {
    int _picco_batch_counter1 = 0;
    int _picco_ind1 = 0;
        for (i = 0; i < N; i++)
      {
        ++_picco_batch_counter1;
      }
    int* _picco_batch_index_array1 = (int*)malloc(sizeof(int) * 3 * _picco_batch_counter1);
    mpz_t* _picco_private_indexed_inputarray1 = (mpz_t*)malloc(sizeof(mpz_t) * _picco_batch_counter1);
    mpz_t* _picco_private_indexed_outputarray1 = (mpz_t*)malloc(sizeof(mpz_t) * _picco_batch_counter1);
    for (int _picco_i = 0; _picco_i < _picco_batch_counter1; _picco_i++)
    {
      mpz_init(_picco_private_indexed_inputarray1[_picco_i]);
      mpz_init(_picco_private_indexed_outputarray1[_picco_i]);
    }
    for (i = 0; i < N; i++)
      {
                __s->smc_set(A, _picco_private_indexed_inputarray1[_picco_ind1], 32, -1, "int", -1);
        _picco_batch_index_array1[3*_picco_ind1] = _picco_ind1;
        _picco_batch_index_array1[3*_picco_ind1+1] = _picco_ind1;
        _picco_batch_index_array1[3*_picco_ind1+2] = i;
        _picco_ind1++;
      }
    __s->smc_privindex_read(_picco_private_indexed_inputarray1, array, _picco_private_indexed_outputarray1, M, _picco_batch_counter1, "int", -1);
    __s->smc_batch(_picco_private_indexed_outputarray1, _picco_private_indexed_outputarray1, result, 32, -1, 32, 0, -1, N, NULL, NULL, -1, _picco_batch_index_array1, _picco_batch_counter1, "=", "int", -1);

    free(_picco_batch_index_array1);
    for (int _picco_i = 0; _picco_i < _picco_batch_counter1; _picco_i++)
    {
      mpz_clear(_picco_private_indexed_inputarray1[_picco_i]);
      mpz_clear(_picco_private_indexed_outputarray1[_picco_i]);
    }
    free(_picco_private_indexed_inputarray1);
    free(_picco_private_indexed_outputarray1);
  }
    j++;
  }
  __s->smc_output(1, result, N, "int", -1);
}


/* smc-compiler generated main() */
int main(int argc, char **argv)
{

 if(argc < 8){
fprintf(stderr,"Incorrect input parameters\n");
fprintf(stderr,"Usage: <id> <runtime-config> <privatekey-filename> <number-of-input-parties> <number-of-output-parties> <input-share> <output>\n");
exit(1);
}

 std::string IO_files[atoi(argv[4]) + atoi(argv[5])];
for(int i = 0; i < argc-6; i++)
   IO_files[i] = argv[6+i];

__s = new SMC_Utils(atoi(argv[1]), argv[2], argv[3], atoi(argv[4]), atoi(argv[5]), IO_files, 3, 1, 64, "9223372036854775907", 1);

struct timeval tv1;
struct timeval tv2;  int _xval = 0;

  gettimeofday(&tv1,NULL);
  _xval = (int) __original_main(argc, argv);
  gettimeofday(&tv2, NULL);
  std::cout << "Time: " << __s->time_diff(&tv1,&tv2) << std::endl;
    FILE *pFile=fopen("atl10_4t", "a+");
  if(pFile==NULL) {
    fprintf(stderr,"Error opening file\n");
  }
  else {
    fprintf(pFile, "%f\n", __s->time_diff(&tv1,&tv2));
  }
  fclose(pFile);
  return (_xval);
}

