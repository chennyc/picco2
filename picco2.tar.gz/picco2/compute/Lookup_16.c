
public int K = 16; // K needs to be equal to K1*K2

public int main()
{
  private int<6> Index,C;
  int A[K];
  public int i;
 for(i = 0; i < K; i++)
{
	A[i]=i;
}
//  smcinput(A, 1); 
  smcinput(Index, 1); 
  
  // measuring performance of a large number of multiplications
  for(i = 0; i < 10000; i++)
    C = A[Index];  
  printf("We are done...\n"); 

  smcoutput(C, 1);
  return 0;
}
