#10
echo "./tl10_4 3 runtime-config private-3.pem 1 1 ./tl_file/tl4_share3 tl4_out"
eval "./tl10_4 3 runtime-config private-3.pem 1 1 ./tl_file/tl4_share3 tl4_out"
sleep 1

echo "./tl10_7 3 runtime-config private-3.pem 1 1 ./tl_file/tl7_share3 tl7_out"
eval "./tl10_7 3 runtime-config private-3.pem 1 1 ./tl_file/tl7_share3 tl7_out"
sleep 1

echo "./tl10_10 3 runtime-config private-3.pem 1 1 ./tl_file/tl10_share3 tl10_out"
eval "./tl10_10 3 runtime-config private-3.pem 1 1 ./tl_file/tl10_share3 tl10_out"
sleep 1

echo "./tl10_13 3 runtime-config private-3.pem 1 1 ./tl_file/tl13_share3 tl13_out"
eval "./tl10_13 3 runtime-config private-3.pem 1 1 ./tl_file/tl13_share3 tl13_out"
sleep 1


echo "./tl10_16 3 runtime-config private-3.pem 1 1 ./tl_file/tl16_share3 tl16_out"
eval "./tl10_16 3 runtime-config private-3.pem 1 1 ./tl_file/tl16_share3 tl16_out"
sleep 1
#100
echo "./tl100_4 3 runtime-config private-3.pem 1 1 ./tl_file/tl4_share3 tl4_out"
eval "./tl100_4 3 runtime-config private-3.pem 1 1 ./tl_file/tl4_share3 tl4_out"
sleep 1


echo "./tl100_7 3 runtime-config private-3.pem 1 1 ./tl_file/tl7_share3 tl7_out"
eval "./tl100_7 3 runtime-config private-3.pem 1 1 ./tl_file/tl7_share3 tl7_out"
sleep 1

echo "./tl100_10 3 runtime-config private-3.pem 1 1 ./tl_file/tl10_share3 tl10_out"
eval "./tl100_10 3 runtime-config private-3.pem 1 1 ./tl_file/tl10_share3 tl10_out"
sleep 1

echo "./tl100_13 3 runtime-config private-3.pem 1 1 ./tl_file/tl13_share3 tl13_out"
eval "./tl100_13 3 runtime-config private-3.pem 1 1 ./tl_file/tl13_share3 tl13_out"
sleep 1


echo "./tl100_16 3 runtime-config private-3.pem 1 1 ./tl_file/tl16_share3 tl16_out"
eval "./tl100_16 3 runtime-config private-3.pem 1 1 ./tl_file/tl16_share3 tl16_out"
sleep 1

#1000
echo "./tl1000_4 3 runtime-config private-3.pem 1 1 ./tl_file/tl4_share3 tl4_out"
eval "./tl1000_4 3 runtime-config private-3.pem 1 1 ./tl_file/tl4_share3 tl4_out"
sleep 1


echo "./tl1000_7 3 runtime-config private-3.pem 1 1 ./tl_file/tl7_share3 tl7_out"
eval "./tl1000_7 3 runtime-config private-3.pem 1 1 ./tl_file/tl7_share3 tl7_out"
sleep 1

echo "./tl1000_10 3 runtime-config private-3.pem 1 1 ./tl_file/tl10_share3 tl10_out"
eval "./tl1000_10 3 runtime-config private-3.pem 1 1 ./tl_file/tl10_share3 tl10_out"
sleep 1

echo "./tl1000_13 3 runtime-config private-3.pem 1 1 ./tl_file/tl13_share3 tl13_out"
eval "./tl1000_13 3 runtime-config private-3.pem 1 1 ./tl_file/tl13_share3 tl13_out"
sleep 1


echo "./tl1000_16 3 runtime-config private-3.pem 1 1 ./tl_file/tl16_share3 tl16_out"
eval "./tl1000_16 3 runtime-config private-3.pem 1 1 ./tl_file/tl16_share3 tl16_out"
sleep 1

#10000
echo "./tl10000_4 3 runtime-config private-3.pem 1 1 ./tl_file/tl4_share3 tl4_out"
eval "./tl10000_4 3 runtime-config private-3.pem 1 1 ./tl_file/tl4_share3 tl4_out"
sleep 1


echo "./tl10000_7 3 runtime-config private-3.pem 1 1 ./tl_file/tl7_share3 tl7_out"
eval "./tl10000_7 3 runtime-config private-3.pem 1 1 ./tl_file/tl7_share3 tl7_out"
sleep 1

echo "./tl10000_10 3 runtime-config private-3.pem 1 1 ./tl_file/tl10_share3 tl10_out"
eval "./tl10000_10 3 runtime-config private-3.pem 1 1 ./tl_file/tl10_share3 tl10_out"
sleep 1

echo "./tl10000_13 3 runtime-config private-3.pem 1 1 ./tl_file/tl13_share3 tl13_out"
eval "./tl10000_13 3 runtime-config private-3.pem 1 1 ./tl_file/tl13_share3 tl13_out"
sleep 1


echo "./tl10000_16 3 runtime-config private-3.pem 1 1 ./tl_file/tl16_share3 tl16_out"
eval "./tl10000_16 3 runtime-config private-3.pem 1 1 ./tl_file/tl16_share3 tl16_out"
sleep 1
