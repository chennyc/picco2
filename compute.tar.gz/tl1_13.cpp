/* File generated from [table_lookup_1_7.c] by PICCO Fri Dec  8 14:39:52 2017
 */

#include <limits.h>

#include <float.h>

//extern void *memcpy(void*,const void*,unsigned int);

//# 1 "ort.onoff.defs"

extern  "C" int   ort_initialize(int*, char***);
 extern "C" void  ort_finalize(int);


/* File generated from [table_lookup_1_7.c] by PICCO Fri Dec  8 14:39:52 2017
 */

#include "smc-compute/SMC_Utils.h"

#include <gmp.h>

#include <omp.h>


SMC_Utils *__s;


int M = 8192;


int  __original_main(int _argc_ignored, char **_argv_ignored)
{
  
  void* _picco_temp_;
   mpz_t _picco_priv_ind1, _picco_priv_ind2, _picco_priv_ind3;
  mpz_init(_picco_priv_ind1);
  mpz_init(_picco_priv_ind2);
  mpz_init(_picco_priv_ind3);
  mpz_t _picco_priv_tmp1, _picco_priv_tmp2;
  mpz_init(_picco_priv_tmp1);
  mpz_init(_picco_priv_tmp2);
mpz_t result;
  mpz_init(result);

  mpz_t* array; 
  array = (mpz_t*)malloc(sizeof(mpz_t) * (M));
  for (int _picco_i = 0; _picco_i < M; _picco_i++)
        mpz_init(array[_picco_i]);

  mpz_t A;
  mpz_init(A);

  __s->smc_input(1, array, M, "int", -1);

  __s->smc_input(1, &A, "int", -1);
  int i = 0;
  for ( ;i < 100; )
  {
      __s->smc_set(A, _picco_priv_ind1, 32, -1, "int", -1);
  __s->smc_privindex_read(_picco_priv_ind1, array, _picco_priv_tmp1, M, "int", -1);
  __s->smc_set(_picco_priv_tmp1, result, 32, 32, "int", -1);
    i++;
  }
  __s->smc_output(1, &result, "int", -1);
}


/* smc-compiler generated main() */
int main(int argc, char **argv)
{

 if(argc < 8){
fprintf(stderr,"Incorrect input parameters\n");
fprintf(stderr,"Usage: <id> <runtime-config> <privatekey-filename> <number-of-input-parties> <number-of-output-parties> <input-share> <output>\n");
exit(1);
}

 std::string IO_files[atoi(argv[4]) + atoi(argv[5])];
for(int i = 0; i < argc-6; i++)
   IO_files[i] = argv[6+i];

__s = new SMC_Utils(atoi(argv[1]), argv[2], argv[3], atoi(argv[4]), atoi(argv[5]), IO_files, 3, 1, 64, "9223372036854775907", 1);

struct timeval tv1;
struct timeval tv2;  int _xval = 0;

  gettimeofday(&tv1,NULL);
  _xval = (int) __original_main(argc, argv);
  gettimeofday(&tv2, NULL);
  std::cout << "Time: " << __s->time_diff(&tv1,&tv2) << std::endl;
  FILE *pFile=fopen("atl1_7t", "a+");
  if(pFile==NULL) {
    fprintf(stderr,"Error opening file\n");
  }
  else {
    fprintf(pFile, "%f\n", __s->time_diff(&tv1,&tv2));
  }
  fclose(pFile);
  return (_xval);
}

