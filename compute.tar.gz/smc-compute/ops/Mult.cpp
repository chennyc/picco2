/*   
   PICCO: A General Purpose Compiler for Private Distributed Computation
   ** Copyright (C) 2013 PICCO Team
   ** Department of Computer Science and Engineering, University of Notre Dame

   PICCO is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   PICCO is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with PICCO. If not, see <http://www.gnu.org/licenses/>.
*/
#include "Mult.h"
#include <sys/wait.h>
#include <sys/time.h>
Mult::Mult(NodeNetwork nodeNet, int nodeID, SecretShare *s) {
	net = nodeNet;
	id = nodeID;
	ss = s;
}

Mult::~Mult() {
	// TODO Auto-generated destructor stub
}

void Mult::doOperation(mpz_t* C, mpz_t* A, mpz_t* B, int size, int threadID){
//	printf("ffffffffffine here \n");
//	struct timeval open_start;
//	struct timeval open_end;
//	unsigned long timer1;

	int peers = ss->getPeers(); 
	int id_p1;
	int id_m1;
	mpz_t *rand_id= (mpz_t*)malloc(sizeof(mpz_t) * size);
	mpz_t* temp = (mpz_t*)malloc(sizeof(mpz_t) * size);
	mpz_t** data = (mpz_t**)malloc(sizeof(mpz_t*) * peers);
	mpz_t** buffer = (mpz_t**)malloc(sizeof(mpz_t*) * peers);
	
	for(int i = 0; i < peers; i++){
		data[i] = (mpz_t*)malloc(sizeof(mpz_t) * size);
		buffer[i] = (mpz_t*)malloc(sizeof(mpz_t) * size);
	}
	//initialziation
	for(int i = 0; i < peers; i++){
		for(int j = 0; j < size; j++){
			mpz_init(data[i][j]);
			mpz_init(buffer[i][j]);
		}
	}

	for(int i = 0; i < size; i++){
		mpz_init(temp[i]);
		mpz_init(rand_id[i]);
	}
	//start computation

//	printf("size is %d\n",size);
//	gettimeofday(&open_start,NULL); //start timer here


	ss->modMul(temp, A, B, size);

//	gettimeofday(&open_end,NULL);//stop timer here

//	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
//	printf("modMul = %ld us\n",timer1);
	if(id==1)
	{
		id_p1=2;
		id_m1=3;
	}else if(id ==2)
	{
		id_p1=3;
		id_m1=1;	
	}
	else
	{
		id_p1=1;
		id_m1=2;
	}
//	printf("fine here \n");
//	gettimeofday(&open_start,NULL); //start timer here
	ss->getShares2(temp, rand_id, data, size);

//	gettimeofday(&open_end,NULL);//stop timer here
//	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
//	printf("getShares2 = %ld us\n",timer1);
//	printf("fine here \n");

//	gettimeofday(&open_start,NULL); //start timer here
//	printf("size is %d\n",size);
	net.multicastToPeers_Mul(data, size, threadID);
//	printf("sizsse is %d\n",size);
//	gettimeofday(&open_end,NULL);//stop timer here
//	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
//	printf("multicastToPeers_mul = %ld us\n",timer1);

	for(int i=0;i<size;i++)
	{
		mpz_set(data[id_m1-1][i],temp[i]);
	}

//	gettimeofday(&open_start,NULL); //start timer here

	ss->reconstructSecret(C, data, size, true);

//	gettimeofday(&open_end,NULL);//stop timer here

//	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
//	printf("reconstructSecret = %ld us\n",timer1);
	//free memory 
	for(int i = 0; i < peers; i++){
		for(int j = 0; j < size; j++){
			mpz_clear(data[i][j]);
			mpz_clear(buffer[i][j]);
		}
		free(data[i]); 
		free(buffer[i]); 
	}
	free(data); 
	free(buffer); 
	for(int i = 0; i < size; i++){
		mpz_clear(temp[i]);
		mpz_clear(rand_id[i]);
	}
	free(temp); 
	free(rand_id); 
//	printf("\n\n\n");
}
